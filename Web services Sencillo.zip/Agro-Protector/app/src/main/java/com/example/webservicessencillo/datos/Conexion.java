package com.example.webservicessencillo.datos;


public class Conexion {
    public static final String URL_WEB_SERVICES ="http://192.168.137.57/agropr";
}
