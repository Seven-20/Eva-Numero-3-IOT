package com.example.webservicessencillo;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.FirebaseFirestore;

public class MainActivity extends AppCompatActivity {

    private FirebaseFirestore db;
    private FirebaseAuth auth;

    private TextView tvTemperatura;
    private TextView tvHumedad;
    private TextView tvSuelo;
    private Button btnLogout;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Inicializar Firebase
        auth = FirebaseAuth.getInstance();
        db = FirebaseFirestore.getInstance();

        // Validar si el usuario está logueado
        if (auth.getCurrentUser() == null) {
            startActivity(new Intent(MainActivity.this, LoginActivity.class));
            finish();
            return;
        }

        // Vincular vistas del XML
        tvTemperatura = findViewById(R.id.tvTemperatura);
        tvHumedad = findViewById(R.id.tvHumedad);
        tvSuelo = findViewById(R.id.tvSuelo);
        btnLogout = findViewById(R.id.btnLogout);

        // Escuchar directamente el documento fijo "actual" en tiempo real
        db.collection("mediciones").document("actual")
                .addSnapshotListener((documentSnapshot, e) -> {
                    if (e != null) {
                        Toast.makeText(MainActivity.this, "Error de sincronización", Toast.LENGTH_SHORT).show();
                        return;
                    }

                    if (documentSnapshot != null && documentSnapshot.exists()) {
                        Double temp = documentSnapshot.getDouble("temperatura");
                        Double hum = documentSnapshot.getDouble("humedad");
                        Long suelo = documentSnapshot.getLong("suelo");

                        tvTemperatura.setText("Temperatura: " + (temp != null ? temp : 0.0) + " °C");
                        tvHumedad.setText("Humedad: " + (hum != null ? hum : 0.0) + " %");
                        tvSuelo.setText("Humedad de Suelo: " + (suelo != null ? suelo : 0));
                    } else {
                        tvTemperatura.setText("Esperando datos...");
                    }
                });

        // Botón para cerrar sesión
        btnLogout.setOnClickListener(v -> {
            auth.signOut();
            Intent intent = new Intent(MainActivity.this, LoginActivity.class);
            startActivity(intent);
            finish();
        });
    }
}