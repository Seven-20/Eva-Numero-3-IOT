<?php
    $c=mysqli_connect("database-1.csbbwfy33re4.us-east-1.rds.amazonaws.com","pi","pi052026","agrobase");

?>
